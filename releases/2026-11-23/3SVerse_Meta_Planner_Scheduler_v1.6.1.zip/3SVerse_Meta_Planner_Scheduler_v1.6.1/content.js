(() => {
  if (globalThis.__metaPlannerSchedulerLoaded) return;
  globalThis.__metaPlannerSchedulerLoaded = true;
  let active = null;

  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  const norm = value => String(value || "").normalize("NFKC").replace(/\s+/g, " ").trim().toLowerCase();
  const visible = element => Boolean(element && element.getClientRects().length && getComputedStyle(element).visibility !== "hidden");
  const controls = () => [...document.querySelectorAll('button,[role="button"],[role="menuitem"],label')].filter(visible);
  const exactControl = text => controls().find(element => norm(element.innerText || element.getAttribute("aria-label")) === norm(text));
  const routeFor = type => type === "reel"
    ? /\/reels_composer\/?$/
    : type === "story"
      ? /\/story_composer\/?$/
      : /\/composer\/?$/;

  function exactHeading(text) {
    return [...document.querySelectorAll('[role="heading"],h1,h2,h3,h4')]
      .find(element => visible(element) && norm(element.innerText || element.textContent) === norm(text));
  }

  function captionEditor() {
    return [...document.querySelectorAll('textarea,[contenteditable="true"][role="textbox"],[contenteditable="true"][role="combobox"],input[type="text"]')]
      .filter(visible)
      .find(element => /write in the dialogue box|write.*post|caption|describe/i.test(
        `${element.getAttribute("aria-label") || ""} ${element.placeholder || ""}`
      ));
  }

  function composerReady(type) {
    if (type === "reel") {
      return routeFor(type).test(location.pathname)
        && Boolean(exactControl("Add video"))
        && Boolean(captionEditor())
        && Boolean(exactControl("Cancel"))
        && Boolean(exactControl("Next"));
    }
    if (type === "story") {
      return routeFor(type).test(location.pathname)
        && Boolean(exactHeading("Create Story"))
        && Boolean(exactControl("Add photo/video"))
        && Boolean(exactControl("Cancel"))
        && Boolean(exactControl("Share"));
    }
    return routeFor(type).test(location.pathname)
      && Boolean(exactHeading("Create post"))
      && Boolean(exactControl("Add photo/video"))
      && Boolean(captionEditor())
      && Boolean(exactControl("Cancel"))
      && Boolean(exactControl("Publish"));
  }

  function screenSummary() {
    const headings = [...document.querySelectorAll("h1,h2,h3")].filter(visible).map(element => element.innerText.trim()).filter(Boolean).slice(-4);
    const buttons = controls().map(element => (element.innerText || element.getAttribute("aria-label") || "").trim()).filter(Boolean).slice(-12);
    return `screen=[${headings.join(" > ") || "no heading"}], controls=[${buttons.join(" | ") || "none"}]`;
  }

  async function waitFor(getter, timeout = 60000, interval = 300, expected = "control") {
    const started = Date.now();
    while (Date.now() - started < timeout) {
      const value = getter();
      if (value) return value;
      await sleep(interval);
    }
    throw new Error(`Meta did not show ${expected} in time; ${screenSummary()}`);
  }

  function modalRoot() {
    return [...document.querySelectorAll('[role="dialog"]')].filter(visible).at(-1) || document.body;
  }

  function createPostButton() {
    return controls().find(element => norm(element.innerText || element.getAttribute("aria-label")) === "create post");
  }

  function createSplitGroup() {
    return createPostButton()?.closest('[role="group"]') || null;
  }

  function createMenuButton() {
    const button = createSplitGroup()?.querySelector('[role="button"][aria-haspopup="menu"]');
    return visible(button) ? button : null;
  }

  function createMenuItem(label) {
    return [...document.querySelectorAll('[role="menuitem"]')]
      .filter(visible)
      .find(element => norm(element.innerText || element.getAttribute("aria-label")) === norm(label));
  }

  function ensureFacebookAndInstagram(type) {
    const sectionName = type === "story" ? "share to" : "post to";
    const heading = [...document.querySelectorAll('[role="heading"],h1,h2,h3,h4')]
      .find(element => visible(element) && norm(element.innerText) === sectionName);
    if (!heading) throw new Error(`Meta's visible '${type === "story" ? "Share to" : "Post to"}' section was not found.`);

    let selection = heading;
    while (selection && selection !== document.body) {
      const accounts = [...selection.querySelectorAll("img")]
        .filter(visible)
        .map(image => norm(image.alt));
      if (accounts.includes("facebook") && accounts.includes("instagram")) break;
      selection = selection.parentElement;
    }
    if (!selection || selection === document.body) {
      throw new Error(`Facebook and Instagram are not both selected in Meta's '${type === "story" ? "Share to" : "Post to"}' control. Select both once, then retry.`);
    }
  }

  async function attachFile(media, type) {
    const root = modalRoot();
    const file = new File([new Uint8Array(media.bytes)], media.name, { type: media.type });
    const transfer = new DataTransfer();
    transfer.items.add(file);
    const acceptInput = input => {
      const accept = input.accept || "";
      return type !== "reel" || !accept || /video/i.test(accept);
    };
    const applyFile = input => {
      if (!input) return false;
      try {
        input.files = transfer.files;
        input.dispatchEvent(new Event("input", { bubbles: true }));
        input.dispatchEvent(new Event("change", { bubbles: true }));
        return true;
      } catch (_) { return false; }
    };
    const existing = [...document.querySelectorAll('input[type="file"]')].find(acceptInput);
    if (existing && applyFile(existing)) return;

    throw new Error(`Meta keeps this upload input detached from the DOM; ${screenSummary()}`);
  }

  async function focusCaption(type) {
    if (type === "story") return false;
    const editor = await waitFor(captionEditor, 30000, 300, "Meta's caption box");
    editor.focus();
    if (editor.isContentEditable) document.execCommand("selectAll", false);
    else {
      editor.select?.();
      const prototype = Object.getPrototypeOf(editor);
      const setter = Object.getOwnPropertyDescriptor(prototype, "value")?.set;
      setter?.call(editor, "");
      editor.dispatchEvent(new Event("input", { bubbles: true }));
      editor.focus();
    }
    return true;
  }

  async function waitForCompletedUpload(fileName, type) {
    const started = Date.now();
    let lastProgress = -1;
    let lastAdvance = started;
    while (Date.now() - started < 300000) {
      const text = document.body.innerText || "";
      const percentages = [...text.matchAll(/(?:^|\s)(\d{1,3})%/g)].map(match => Number(match[1])).filter(Number.isFinite);
      const progress = percentages.length ? Math.max(...percentages) : -1;
      if (progress > lastProgress) {
        lastProgress = progress;
        lastAdvance = Date.now();
      }
      const previewReady = /safe to publish|no copyright issues|reels?\s*\u00b7\s*\d+\s*seconds?/i.test(text);
      const nextReady = Boolean(enabledExactButton("Next"));
      const postReady = Boolean(enabledExactButton("Publish"));
      const storyReady = Boolean(enabledExactButton("Share"));
      const actionReady = type === "reel" ? nextReady : type === "post" ? postReady : storyReady;
      if (actionReady && (type !== "reel" || progress >= 100 || previewReady || text.includes(fileName))) return true;
      if (progress === 0 && Date.now() - lastAdvance > 45000) {
        throw new Error(`Meta upload for ${fileName} stayed at 0% for 45 seconds.`);
      }
      if (progress > 0 && progress < 100 && Date.now() - lastAdvance > 90000) {
        throw new Error(`Meta upload for ${fileName} stopped advancing at ${progress}%.`);
      }
      await sleep(700);
    }
    throw new Error(`Meta did not complete the upload for ${fileName} within 5 minutes; ${screenSummary()}`);
  }

  function composerText() {
    return norm(modalRoot().innerText);
  }

  function enabledExactButton(text) {
    return [...modalRoot().querySelectorAll('button,[role="button"]')].filter(visible).filter(element =>
      norm(element.innerText || element.getAttribute("aria-label")) === norm(text)
      && !element.matches(':disabled,[aria-disabled="true"]')
    ).at(-1);
  }

  function setNativeValue(input, value) {
    const prototype = Object.getPrototypeOf(input);
    const setter = Object.getOwnPropertyDescriptor(prototype, "value")?.set;
    if (setter) setter.call(input, value); else input.value = value;
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
    input.dispatchEvent(new Event("blur", { bubbles: true }));
  }

  function storyShareSwitch() {
    return [...document.querySelectorAll('[role="switch"],input[type="checkbox"]')]
      .find(element => visible(element) && /share to facebook story/i.test(element.getAttribute("aria-label") || ""));
  }

  function postScheduleSwitch() {
    return [...document.querySelectorAll('[role="switch"],input[type="checkbox"]')]
      .find(element => {
        if (!visible(element)) return false;
        const label = element.id ? document.querySelector(`label[for="${CSS.escape(element.id)}"]`) : element.closest("label");
        return norm(element.innerText || element.getAttribute("aria-label") || label?.innerText) === "set date and time";
      });
  }

  function scheduleChoice(type = active?.item?.type) {
    if (type === "post") return postScheduleSwitch();
    return [...document.querySelectorAll('button,[role="button"],[role="radio"],[role="checkbox"],input[type="radio"],input[type="checkbox"]')]
      .find(element => {
        if (!visible(element)) return false;
        const label = element.id ? document.querySelector(`label[for="${CSS.escape(element.id)}"]`) : element.closest("label");
        return norm(element.innerText || element.getAttribute("aria-label") || label?.innerText) === "schedule";
      });
  }

  function checked(element) {
    return Boolean(element && (
      element.checked
      || element.getAttribute("aria-checked") === "true"
      || element.getAttribute("aria-pressed") === "true"
      || element.getAttribute("aria-selected") === "true"
    ));
  }

  function reelStageKey() {
    return [...document.querySelectorAll('button,[role="button"]')]
      .filter(visible)
      .map(element => norm(element.getAttribute("aria-label") || element.innerText))
      .filter(label => /^(create|edit|share) (pending|completed) status$/.test(label))
      .join("|");
  }

  async function activateNext() {
    const beforeStage = reelStageKey();
    const next = enabledExactButton("Next");
    if (!next) throw new Error(`Meta's enabled Next button was not found; ${screenSummary()}`);
    next.scrollIntoView({ block: "center", inline: "center" });
    next.focus({ preventScroll: true });
    next.click();
    await waitFor(
      () => {
        const state = flowState(active.item);
        return state.shareStep || (state.stageKey && state.stageKey !== beforeStage) ? state : null;
      },
      20000,
      250,
      "the next Reel stage after clicking Next"
    );
    return flowState(active.item);
  }

  async function activateSchedule() {
    if (document.querySelectorAll("input[placeholder='dd/mm/yyyy']").length >= 2) return true;
    for (let attempt = 0; attempt < 3; attempt += 1) {
      const option = scheduleChoice(active?.item?.type);
      if (!option) throw new Error(`Meta's Schedule option was not found; ${screenSummary()}`);
      option.scrollIntoView({ block: "center", inline: "center" });
      option.focus({ preventScroll: true });
      option.click();
      try {
        await waitFor(
          () => document.querySelectorAll("input[placeholder='dd/mm/yyyy']").length >= 2,
          5000,
          200,
          "Facebook and Instagram date fields"
        );
        return true;
      } catch (_) {
        await new Promise(resolve => setTimeout(resolve, 300));
      }
    }
    throw new Error(`Meta did not activate the Schedule option; ${screenSummary()}`);
  }

  function flowState(item) {
    const rootText = norm(modalRoot().innerText);
    const story = storyShareSwitch();
    const schedule = scheduleChoice(item.type);
    const itemShareStep = item.type === "reel"
      ? /scheduling options/.test(rootText)
      : item.type === "post"
        ? /create post/.test(rootText) && Boolean(postScheduleSwitch())
        : /create story/.test(rootText) && Boolean(scheduleChoice("story"));
    return {
      online: navigator.onLine,
      captionRetained: item.type === "story" || composerText().includes(norm(item.caption)),
      nextReady: Boolean(enabledExactButton("Next")),
      stageKey: item.type === "reel" ? reelStageKey() : item.type,
      shareStep: itemShareStep,
      scheduleSelected: checked(schedule) || document.querySelectorAll("input[placeholder='dd/mm/yyyy']").length >= 2,
      storyAvailable: Boolean(story),
      storyOn: checked(story),
      fieldsReady: document.querySelectorAll("input[placeholder='dd/mm/yyyy']").length >= 2,
      finalReady: Boolean(enabledExactButton("Schedule")),
      summary: screenSummary()
    };
  }

  function scheduleMatches(date, time) {
    const [year, month, day] = date.split("-");
    const [hours, minutes] = time.split(":").map(Number);
    const dates = [...document.querySelectorAll("input[placeholder='dd/mm/yyyy']")].filter(visible);
    const hourInputs = [...document.querySelectorAll("input[role='spinbutton'][aria-label='hours']")].filter(visible);
    const minuteInputs = [...document.querySelectorAll("input[role='spinbutton'][aria-label='minutes']")].filter(visible);
    if (dates.length < 2 || hourInputs.length < 2 || minuteInputs.length < 2) return false;
    const dateOk = dates.every(input => norm(input.value).includes(norm(`${Number(day)} ${new Date(Number(year), Number(month) - 1, 1).toLocaleString("en", { month: "long" })} ${year}`)));
    const timeOk = hourInputs.every(input => Number(input.getAttribute("aria-valuenow")) === hours)
      && minuteInputs.every(input => Number(input.getAttribute("aria-valuenow")) === minutes);
    return dateOk && timeOk;
  }

  async function verifyScheduled() {
    await waitFor(() => {
      const liveText = [...document.querySelectorAll('[role="alert"],[role="status"],[aria-live]')]
        .filter(visible)
        .map(element => element.innerText || element.textContent || "")
        .join(" ");
      const text = norm(`${liveText} ${document.body.innerText}`);
      return [
        /you scheduled a (?:post|reel|story) through meta business suite/,
        /your (?:facebook |instagram )?(?:post|reel|story) (?:has been|is|was) scheduled/,
        /(?:post|reel|story) (?:has been )?scheduled successfully/,
        /(?:post|reel|story) scheduled\b/,
        /successfully scheduled (?:your )?(?:post|reel|story)/,
        /your (?:facebook |instagram )?(?:post|reel|story) (?:has been|is|was) published/,
        /(?:post|reel|story) (?:has been )?published successfully/
      ].some(pattern => pattern.test(text));
    }, 180000, 500, "Meta's explicit scheduled/published confirmation");
    // Keep the confirmed page untouched briefly so Meta can finish its own
    // post-submit transition before the workflow tab is reused.
    await sleep(5000);
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message.type === "PING") { sendResponse({ ok: true }); return; }
    if (message.type === "GET_META_LAUNCH_STATE") {
      (async () => {
        const type = message.item?.type;
        sendResponse({
          ok: true,
          state: {
            plannerReady: location.pathname.includes("content_calendar")
              && Boolean(createPostButton())
              && Boolean(createMenuButton()),
            reelMenuReady: Boolean(createMenuItem("Create reel")),
            storyMenuReady: Boolean(createMenuItem("Create Story")),
            composerReady: Boolean(type && composerReady(type)),
            summary: screenSummary()
          }
        });
      })().catch(error => sendResponse({ ok: false, error: error.message }));
      return true;
    }
    if (message.type === "WAIT_META_COMPOSER") {
      (async () => {
        const item = message.item;
        if (!item?.type) throw new Error("Meta item type is missing.");
        await waitFor(() => composerReady(item.type), 60000, 300, `the ${item.type} composer selected from Planner`);
        ensureFacebookAndInstagram(item.type);
        active = { item, captionReady: false };
        sendResponse({ ok: true, composerReady: true });
      })().catch(error => sendResponse({ ok: false, error: error.message }));
      return true;
    }
    if (message.type === "OPEN_META_UPLOAD") {
      (async () => {
        const upload = controls().find(element => /add (video|photo|media)|upload (video|photo|media)/i.test(element.innerText || element.getAttribute("aria-label") || ""));
        if (!upload) throw new Error(`Meta upload button was not found; ${screenSummary()}`);
        upload.click();
        sendResponse({ ok: true });
      })().catch(error => sendResponse({ ok: false, error: error.message }));
      return true;
    }
    if (message.type === "ATTACH_META_FILE") {
      (async () => {
        if (!active) throw new Error("Meta scheduling state was lost. Retry this item.");
        if (!Array.isArray(message.media?.bytes) || !message.media.bytes.length) {
          throw new Error("The selected media bytes were not available to the Meta uploader.");
        }
        await attachFile(message.media, message.item.type);
        sendResponse({ ok: true, attached: true });
      })().catch(error => sendResponse({ ok: false, error: error.message }));
      return true;
    }
    if (message.type === "PREPARE_META_ITEM") {
      (async () => {
        if (!active) active = { item: message.item, captionReady: false };
        await waitForCompletedUpload(message.item.file.name, message.item.type);
        active.captionReady = await focusCaption(message.item.type);
        sendResponse({ ok: true, captionReady: active.captionReady, captionOptional: message.item.type === "story" });
      })().catch(error => sendResponse({ ok: false, error: error.message }));
      return true;
    }
    if (message.type === "GET_META_FLOW_STATE") {
      (async () => {
        if (!active) throw new Error("Meta scheduling state was lost. Retry this item.");
        sendResponse({ ok: true, state: flowState(active.item) });
      })().catch(error => sendResponse({ ok: false, error: error.message }));
      return true;
    }
    if (message.type === "ACTIVATE_META_NEXT") {
      (async () => {
        if (!active || active.item.type !== "reel") throw new Error("The active item is not a Reel.");
        const state = await activateNext();
        sendResponse({ ok: true, state });
      })().catch(error => sendResponse({ ok: false, error: error.message }));
      return true;
    }
    if (message.type === "ACTIVATE_META_SCHEDULE") {
      (async () => {
        await activateSchedule();
        sendResponse({ ok: true, scheduleReady: true });
      })().catch(error => sendResponse({ ok: false, error: error.message }));
      return true;
    }
    if (message.type === "WAIT_META_SCHEDULE_FIELDS") {
      (async () => {
        await waitFor(() => document.querySelectorAll("input[placeholder='dd/mm/yyyy']").length >= 2, 15000, 250, "Facebook and Instagram date fields");
        sendResponse({ ok: true, scheduleReady: true });
      })().catch(error => sendResponse({ ok: false, error: error.message }));
      return true;
    }
    if (message.type === "PREFLIGHT_META_ITEM") {
      (async () => {
        if (!active) throw new Error("Meta scheduling state was lost. Retry this item.");
        await waitFor(() => scheduleMatches(message.item.date, message.item.time), 15000, 250, "the requested Facebook and Instagram date/time");
        await waitFor(() => enabledExactButton("Schedule"), 15000, 250, "the final Schedule button");
        sendResponse({ ok: true, ready: true });
      })().catch(error => sendResponse({ ok: false, error: error.message }));
      return true;
    }
    if (message.type === "VERIFY_META_ITEM") {
      (async () => {
        if (!active) throw new Error("Meta scheduling state was lost. Retry this item.");
        await verifyScheduled();
        active = null;
        sendResponse({ ok: true, scheduled: true });
      })().catch(error => sendResponse({ ok: false, error: error.message }));
      return true;
    }
  });
})();
